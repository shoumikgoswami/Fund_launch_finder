import styled from "styled-components";

const LetsConnectConstellations = styled.h1`
  margin: 0;
  align-self: stretch;
  position: relative;
  font-size: inherit;
  letter-spacing: -0.02em;
  font-weight: 600;
  font-family: inherit;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-5xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
  }
`;
const LetsAlignOur = styled.div`
  width: 415px;
  position: relative;
  font-size: var(--text-size);
  letter-spacing: -0.01em;
  color: var(--color-gray-1600);
  display: inline-block;
  max-width: 100%;
`;
const FormHeading = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 8px 0px;
  max-width: 100%;
`;
const LastName = styled.input`
  width: 75px;
  border: none;
  outline: none;
  font-family: var(--text);
  font-size: var(--font-size-mini);
  background-color: transparent;
  height: 18px;
  position: relative;
  letter-spacing: -0.01em;
  color: var(--color-gray-1200);
  text-align: left;
  display: inline-block;
  padding: 0;
`;
const EmailFrame = styled.div`
  flex: 1;
  border-radius: var(--br-8xs);
  background-color: var(--color-gray-1300);
  border: 1px solid var(--color-gray-1400);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-sm);
  min-width: 154px;
`;
const FirstName = styled.input`
  width: 76px;
  border: none;
  outline: none;
  font-family: var(--text);
  font-size: var(--font-size-mini);
  background-color: transparent;
  height: 18px;
  position: relative;
  letter-spacing: -0.01em;
  color: var(--color-gray-1200);
  text-align: left;
  display: inline-block;
  padding: 0;
`;
const InputFrames = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 0px 14px;
  @media screen and (max-width: 450px) {
    flex-wrap: wrap;
  }
`;
const Email = styled.input`
  width: 37px;
  border: none;
  outline: none;
  font-family: var(--text);
  font-size: var(--font-size-mini);
  background-color: transparent;
  height: 18px;
  position: relative;
  letter-spacing: -0.01em;
  color: var(--color-gray-1200);
  text-align: left;
  display: inline-block;
  padding: 0;
`;
const InputFrames1 = styled.div`
  align-self: stretch;
  border-radius: var(--br-8xs);
  background-color: var(--color-gray-1300);
  border: 1px solid var(--color-gray-1400);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-sm);
  z-index: unset;
`;
const PhoneNumber = styled.input`
  width: 105px;
  border: none;
  outline: none;
  font-family: var(--text);
  font-size: var(--font-size-mini);
  background-color: transparent;
  height: 18px;
  position: relative;
  letter-spacing: -0.01em;
  color: var(--color-gray-1200);
  text-align: left;
  display: inline-block;
  padding: 0;
`;
const InputFrames2 = styled.div`
  align-self: stretch;
  border-radius: var(--br-8xs);
  background-color: var(--color-gray-1300);
  border: 1px solid var(--color-gray-1400);
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  padding: var(--padding-xs) var(--padding-sm);
`;
const InputFrames3 = styled.textarea`
  border: 1px solid var(--color-gray-1400);
  background-color: var(--color-gray-1300);
  height: 111px;
  width: auto;
  outline: none;
  align-self: stretch;
  border-radius: var(--br-8xs);
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-xs) var(--padding-sm);
  font-family: var(--text);
  font-size: var(--font-size-mini);
  color: var(--color-gray-1200);
`;
const SendItTo = styled.div`
  position: relative;
  font-size: var(--font-size-mini);
  letter-spacing: -0.01em;
  font-weight: 500;
  font-family: var(--text);
  color: var(--color-white);
  text-align: left;
`;
const Image2Icon = styled.img`
  height: 12px;
  width: 25px;
  position: relative;
  object-fit: contain;
  mix-blend-mode: screen;
`;
const InputFrames4 = styled.button`
  cursor: pointer;
  border: none;
  padding: var(--padding-xs) var(--padding-3xs);
  background-color: transparent;
  align-self: stretch;
  border-radius: var(--br-8xs);
  background: linear-gradient(90deg, #763af5, #a604f2);
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  gap: 0px 10px;
  white-space: nowrap;
`;
const Form1 = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: var(--gap-sm);
`;
const FormWrapper = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 41px 0px;
  max-width: 100%;
  z-index: 1;
  @media screen and (max-width: 450px) {
    gap: 20px 0px;
  }
`;
const LastNameInput = styled.div`
  width: 426px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  padding: var(--padding-9xl) 0px 0px;
  box-sizing: border-box;
  min-width: 426px;
  max-width: 100%;
  @media screen and (max-width: 1300px) {
    flex: 1;
  }
  @media screen and (max-width: 1125px) {
    min-width: 100%;
  }
`;
const TextFramesIcon = styled.img`
  position: absolute;
  height: 100%;
  top: 0px;
  bottom: 0px;
  left: 0px;
  max-height: 100%;
  width: 1112px;
  overflow: hidden;
`;
const LunarQuoteIcon = styled.img`
  position: absolute;
  top: 56px;
  left: 1028px;
  width: 134px;
  height: 558px;
  overflow: hidden;
  z-index: 1;
`;
const SplitFrames = styled.div`
  height: 670px;
  width: 1162px;
  position: absolute;
  margin: 0 !important;
  top: -76px;
  left: -579px;
`;
const TwoLunarMonths = styled.div`
  align-self: stretch;
  position: relative;
  letter-spacing: -0.01em;
`;
const IrinelTraista = styled.div`
  position: relative;
  letter-spacing: -0.01em;
  font-weight: 500;
  color: var(--color-gray-1600);
`;
const ImageBox = styled.div`
  flex: 1;
  border-radius: var(--br-xs);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-end;
  padding: var(--padding-406xl) var(--padding-3xl) var(--padding-29xl)
    var(--padding-9xl);
  box-sizing: border-box;
  gap: 6px 0px;
  background-image: url("/image-box@3x.png");
  background-size: cover;
  background-repeat: no-repeat;
  background-position: top;
  mix-blend-mode: normal;
  max-width: 100%;
  z-index: 2;
`;
const AdditionalFrame = styled.div`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  position: relative;
  min-width: 335px;
  max-width: 100%;
  font-size: var(--text-size);
  color: var(--color-gray-1500);
`;
const ConnectConstellationsRoot = styled.section`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  gap: 0px 79px;
  max-width: 100%;
  text-align: left;
  font-size: var(--h2-size);
  color: var(--color-white);
  font-family: var(--text);
  @media screen and (max-width: 1300px) {
    flex-wrap: wrap;
  }
  @media screen and (max-width: 1125px) {
    gap: 0px 39px;
  }
  @media screen and (max-width: 800px) {
    gap: 0px 20px;
  }
`;

const ConnectConstellations = () => {
  return (
    <ConnectConstellationsRoot>
      <LastNameInput>
        <FormWrapper>
          <FormHeading>
            <LetsConnectConstellations>
              Let’s connect constellations
            </LetsConnectConstellations>
            <LetsAlignOur>
              Let's align our constellations! Reach out and let the magic of
              collaboration illuminate our skies.
            </LetsAlignOur>
          </FormHeading>
          <Form1>
            <InputFrames>
              <EmailFrame>
                <LastName placeholder="Last Name" type="text" />
              </EmailFrame>
              <EmailFrame>
                <FirstName placeholder="First Name" type="text" />
              </EmailFrame>
            </InputFrames>
            <InputFrames1>
              <Email placeholder="Email" type="text" />
            </InputFrames1>
            <InputFrames2>
              <PhoneNumber placeholder="Phone Number" type="text" />
            </InputFrames2>
            <InputFrames3 placeholder="Message" rows={5} cols={21} />
            <InputFrames4>
              <SendItTo>Send it to the moon</SendItTo>
              <Image2Icon alt="" src="/image-2@2x.png" />
            </InputFrames4>
          </Form1>
        </FormWrapper>
      </LastNameInput>
      <AdditionalFrame>
        <SplitFrames>
          <TextFramesIcon alt="" src="/text-frames.svg" />
          <LunarQuoteIcon loading="lazy" alt="" src="/frame-1.svg" />
        </SplitFrames>
        <ImageBox>
          <TwoLunarMonths>
            “Two lunar months revealed Earth's fragile beauty against vast
            silence, transforming my view of our place in the universe.
          </TwoLunarMonths>
          <IrinelTraista>Irinel Traista</IrinelTraista>
        </ImageBox>
      </AdditionalFrame>
    </ConnectConstellationsRoot>
  );
};

export default ConnectConstellations;
