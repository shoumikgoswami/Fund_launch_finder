import styled from "styled-components";
import ConnectConstellations from "../components/ConnectConstellations";

const GetIn = styled.span``;
const Touch1 = styled.span`
  color: rgba(255, 255, 255, 0.3);
`;
const GetInTouchContainer = styled.div`
  position: relative;
  letter-spacing: -0.03em;
  font-weight: 800;
  opacity: 0.9;
  @media screen and (max-width: 800px) {
    font-size: var(--font-size-22xl);
  }
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-6xl);
  }
`;
const ReachOut = styled.div`
  align-self: stretch;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  padding: 0px var(--padding-xl);
`;
const ReachOutAnd = styled.h3`
  margin: 0;
  position: relative;
  font-size: var(--font-size-3xl);
  letter-spacing: -0.02em;
  font-weight: 500;
  font-family: inherit;
  color: var(--color-gray-1500);
  @media screen and (max-width: 450px) {
    font-size: var(--font-size-lg);
  }
`;
const GetInTouch = styled.div`
  width: 626px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: flex-start;
  gap: 7px 0px;
  max-width: 100%;
`;
const FormFrame = styled.div`
  width: 990px;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  max-width: 100%;
`;
const ContactForm = styled.main`
  width: 100%;
  margin: 0 !important;
  position: absolute;
  height: 100%;
  top: 0px;
  right: 0px;
  bottom: 0px;
  left: 0px;
  background-color: var(--dark-navi);
  overflow: hidden;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  justify-content: flex-start;
  padding: var(--padding-48xl) 252px 125px 239px;
  box-sizing: border-box;
  gap: 86px 0px;
  max-width: 100%;
  text-align: left;
  font-size: 81.8px;
  color: var(--color-white);
  font-family: var(--text);
  @media screen and (max-width: 800px) {
    gap: 43px 0px;
    padding-left: var(--padding-100xl);
    padding-right: 126px;
    box-sizing: border-box;
  }
  @media screen and (max-width: 450px) {
    gap: 21px 0px;
    padding-left: var(--padding-xl);
    padding-right: var(--padding-xl);
    box-sizing: border-box;
  }
`;
const MainRoot = styled.div`
  width: 100%;
  height: 947px;
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: flex-start;
  letter-spacing: normal;
  @media screen and (max-width: 1300px) {
    height: auto;
    min-height: 947;
  }
`;

const Main = () => {
  return (
    <MainRoot>
      <ContactForm>
        <FormFrame>
          <GetInTouch>
            <ReachOut>
              <GetInTouchContainer>
                <GetIn>{`Get in `}</GetIn>
                <Touch1>touch</Touch1>
              </GetInTouchContainer>
            </ReachOut>
            <ReachOutAnd>
              Reach out, and let's create a universe of possibilities together!
            </ReachOutAnd>
          </GetInTouch>
        </FormFrame>
        <ConnectConstellations />
      </ContactForm>
    </MainRoot>
  );
};

export default Main;
